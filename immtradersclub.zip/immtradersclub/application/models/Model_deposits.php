<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_deposits extends MY_Model	 {

	public $tbl_name = "deposits";

}
