<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_royalty extends MY_Model	 {

	public $tbl_name = "royalty_income";

}
