<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_banks extends MY_Model	 {

	public $tbl_name = "company_banks";

}
