<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_ranks extends MY_Model	 {

	public $tbl_name = "ranks";

}
