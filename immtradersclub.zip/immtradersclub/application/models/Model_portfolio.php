<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_portfolio extends MY_Model	 {

	public $tbl_name = "portfolio";

}
