<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_packages extends MY_Model	 {

	public $tbl_name = "package_type";

}
