<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_purchasehistory extends MY_Model	 {

	public $tbl_name = "purchasehistory";

}
